Course Diagrams
